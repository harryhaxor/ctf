#!/bin/bash
pip install flask
python app.py
