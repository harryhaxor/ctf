# Blind Justice - CTF Challenge

## Description

A hard-level web challenge focused on **time-based blind SQL injection**. The attacker must infer the admin's password through response timing analysis.

## Setup

### Requirements

- Python 3.x
- Flask

### Installation

```bash
pip install flask
python app.py
```

### Access

- Login page: `http://localhost:5000/login`
- Admin flag at: `http://localhost:5000/admin` (requires cookie session as admin)

## Flag

```
flag{n0_0utput_n0_pr0bl3m_bl1nd_5qli}
```
